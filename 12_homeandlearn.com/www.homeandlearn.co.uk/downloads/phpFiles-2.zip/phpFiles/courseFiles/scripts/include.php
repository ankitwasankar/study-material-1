<html>
<HEAD>
<TITLE>Include files</TITLE>
</HEAD>

<body>
<H3>Normal text here </H3>
Normal text written in a HTML Editor

<H3>Include File here</H3>

<?PHP include "textfile.txt" ; ?>

</body>
</html>


