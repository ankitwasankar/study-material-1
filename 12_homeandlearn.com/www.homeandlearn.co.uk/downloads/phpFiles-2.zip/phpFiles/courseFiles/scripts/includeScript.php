<?PHP
include "myOtherScript.php";

print "This was printed from the includeScript.php";

print "<BR>";
doPrint();

?>