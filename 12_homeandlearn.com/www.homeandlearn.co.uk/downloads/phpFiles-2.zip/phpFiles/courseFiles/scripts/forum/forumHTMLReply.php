<?php
	//================================================================
	//	THE TABLE AND LINKS FOR THE POSTS PAGES
	//===============================================================
	$tableHeaders = '';
	$TableStart = "<TABLE WIDTH = 600>";
	$TableEnd = "</TABLE>";
	$RowStart = "<TR>";
	$RowEnd = "</TR>";
	$tdStart = "<TD WIDTH = 200 align = center valign = middle bgcolor =#EBEBEB>";
	$tdEnd = "</TD>";

	$tableHeaders2 = "<TR WIDTH = 200 height = 10 align = center valign = middle bgcolor =#00EBEB>";
	$tableHeaders2 = $tableHeaders2 . "<TD>Posted By</TD><TD>Original Post</TD><TD>Date</TD></TR>";


	$tableHeaders = "<TR WIDTH = 200 height = 10 align = center valign = middle bgcolor =#00EBEB>";
	$tableHeaders = $tableHeaders . "<TD>Reply By</TD><TD>Reply</TD><TD>Date</TD></TR>";

?>