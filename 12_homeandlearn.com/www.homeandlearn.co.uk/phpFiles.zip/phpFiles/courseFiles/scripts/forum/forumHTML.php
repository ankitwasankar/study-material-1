<?php
	//================================================================
	//	THE TABLE AND LINKS FOR THE POSTS PAGES
	//===============================================================
	$TableStart = "<TABLE WIDTH = 600>";
	$TableEnd = "</TABLE>";
	$RowStart = "<TR >";
	$RowEnd = "</TR>";
	$tdStart = "<TD WIDTH = 200 align = center valign = middle bgcolor =#EBEBEB>";
	$tdEnd = "</TD>";
	$tableHeaders = "<TR WIDTH = 200 height = 10 align = center valign = middle bgcolor =#00EBEB>";
	$tableHeaders = $tableHeaders . "<TD>Posted By</TD><TD>Post Topic</TD><TD>Number of Replies</TD></TR>";

	$hrefStart = "<A HREF = pageReply.php?rID";
	$hrefEnd = "</A>";
?>