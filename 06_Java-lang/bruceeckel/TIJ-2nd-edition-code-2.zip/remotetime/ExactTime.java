/*
 * File: ./REMOTETIME/EXACTTIME.JAVA
 * From: .\C15\CORBA\EXACTTIME.IDL
 * Date: Mon Mar 13 14:02:18 2000
 *   By: C:\PROGTO~1\JAVA\BIN\IDLTOJ~1.EXE Java IDL 1.2 Aug 18 1998 16:25:34
 */

package remotetime;
public interface ExactTime
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
    String getTime()
;
}
